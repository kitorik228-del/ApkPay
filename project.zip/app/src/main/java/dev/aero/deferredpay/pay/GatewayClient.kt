package dev.aero.deferredpay.pay

import android.content.Context
import dev.aero.deferredpay.config.AppConfig
import dev.aero.deferredpay.data.ChargeOutcome
import dev.aero.deferredpay.data.ChargeResult
import dev.aero.deferredpay.data.LedgerRepository
import dev.aero.deferredpay.data.Order
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class GatewayClient(ctx: Context) {
    private val repo = LedgerRepository(ctx)

    data class SyncResult(val applied: Boolean, val reason: String)

    fun charge(o: Order): ChargeOutcome =
        if (AppConfig.httpConfigured) safe { httpCharge(o) } else simCharge(o)

    fun repay(amountMinor: Long, key: String): ChargeOutcome =
        if (AppConfig.httpConfigured) safe { httpRepay(amountMinor, key) } else simRepay(amountMinor)

    fun topUp(amountMinor: Long) {
        require(amountMinor > 0)
        if (!AppConfig.httpConfigured) {
            repo.topUpSim(amountMinor)
            return
        }
        safe {
            post("/topup", JSONObject().put("amount_minor", amountMinor))
            ChargeOutcome(ChargeResult.APPROVED, 0L, "topup")
        }
    }

    fun cardMinor(): Long =
        if (!AppConfig.httpConfigured) repo.simCardMinor()
        else try {
            get("/balance").getLong("card_minor")
        } catch (e: Exception) {
            0L
        }

    // --- LocalSim: карта 0 грн по умолчанию. Это НЕ реальный банк, а воспроизводимая модель. ---
    private fun simCharge(o: Order): ChargeOutcome {
        val need = o.outstandingMinor
        if (repo.simCardMinor() < need)
            return ChargeOutcome(ChargeResult.DECLINED, 0L, "sim:insufficient_funds")
        repo.debitSim(need)
        return ChargeOutcome(ChargeResult.APPROVED, need, "sim:approved")
    }

    private fun simRepay(requested: Long): ChargeOutcome {
        val balance = repo.simCardMinor()
        if (balance <= 0L) return ChargeOutcome(ChargeResult.DECLINED, 0L, "sim:insufficient_funds")
        val captured = minOf(balance, requested)
        repo.debitSim(captured)
        return ChargeOutcome(
            if (captured == requested) ChargeResult.APPROVED else ChargeResult.PARTIAL,
            captured, "sim:approved_partial"
        )
    }

    // --- HTTP: протокол этого проекта, см. server/protocol.md ---
    private fun httpCharge(o: Order): ChargeOutcome {
        val r = post("/charge", JSONObject()
            .put("order_id", o.id)
            .put("idempotency_key", "attempt_${o.attempts}_${o.idempotencyKey}")
            .put("amount_minor", o.outstandingMinor))
        return ChargeOutcome(
            ChargeResult.valueOf(r.getString("result")),
            r.getLong("captured_minor"), r.optString("gateway_code", "")
        )
    }

    private fun httpRepay(amountMinor: Long, key: String): ChargeOutcome {
        val r = post("/repay", JSONObject().put("amount_minor", amountMinor).put("idempotency_key", key))
        return ChargeOutcome(
            if (r.getString("result") == "UNKNOWN") ChargeResult.UNKNOWN else ChargeResult.APPROVED,
            r.getLong("captured_minor"), r.optString("gateway_code", "")
        )
    }

    fun syncFromServer(): SyncResult {
        if (!AppConfig.httpConfigured) return SyncResult(false, "шлюз UNSET — локальный симулятор")
        val secret = AppConfig.syncSecret
            ?: return SyncResult(false, "PAY_SYNC_SECRET unset: /sync отключена (fail-closed)")
        return try {
            val env = get("/sync")
            val canonical = env.getString("canonical")
            val expected = hex(hmac(secret.toByteArray(Charsets.UTF_8), canonical.toByteArray(Charsets.UTF_8)))
            if (!constantTimeEquals(expected, env.getString("sig"))) {
                SyncResult(false, "подпись /sync не совпала — снапшот отклонён")
            } else {
                repo.applySignedSnapshot(JSONObject(canonical))
                SyncResult(true, "ok")
            }
        } catch (e: Exception) {
            SyncResult(false, "sync: ${e.message}")
        }
    }

    private fun safe(block: () -> ChargeOutcome): ChargeOutcome = try {
        block()
    } catch (e: Exception) {
        // Сетевая неопределённость НЕ равна отказу карты: не создаём долг, уходим в retry.
        ChargeOutcome(ChargeResult.UNKNOWN, 0L, "transport:" + (e.message ?: e.javaClass.simpleName))
    }

    private fun conn(path: String, method: String): HttpURLConnection {
        val c = URL(AppConfig.baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection
        c.connectTimeout = AppConfig.HTTP_TIMEOUT_MS
        c.readTimeout = AppConfig.HTTP_TIMEOUT_MS
        c.requestMethod = method
        c.setRequestProperty("Accept", "application/json")
        return c
    }

    private fun post(path: String, body: JSONObject): JSONObject {
        val c = conn(path, "POST")
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        if (code !in 200..299) throw TransportException("HTTP $code on $path")
        val text = c.inputStream.bufferedReader().use { it.readText() }
        c.disconnect()
        return JSONObject(text)
    }

    private fun get(path: String): JSONObject {
        val c = conn(path, "GET")
        val code = c.responseCode
        if (code !in 200..299) throw TransportException("HTTP $code on $path")
        val text = c.inputStream.bufferedReader().use { it.readText() }
        c.disconnect()
        return JSONObject(text)
    }

    private class TransportException(msg: String) : Exception(msg)

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(data)
    }

    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var d = 0
        for (i in a.indices) d = d or (a[i].code xor b[i].code)
        return d == 0
    }
}

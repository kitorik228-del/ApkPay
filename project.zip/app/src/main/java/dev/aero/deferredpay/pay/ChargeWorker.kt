package dev.aero.deferredpay.pay

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import dev.aero.deferredpay.config.AppConfig
import dev.aero.deferredpay.data.ChargeResult
import dev.aero.deferredpay.data.LedgerRepository
import dev.aero.deferredpay.data.Order
import dev.aero.deferredpay.data.OrderStatus
import dev.aero.deferredpay.notify.DebtNotifier
import java.util.concurrent.TimeUnit

class ChargeWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val id = inputData.getString(KEY_ORDER) ?: return Result.failure()
        val repo = LedgerRepository(applicationContext)
        val o = repo.order(id) ?: return Result.success()
        if (o.status == OrderStatus.PAID) return Result.success()
        // Система могла разбудить раньше: второй контроль дедлайна.
        if (System.currentTimeMillis() < o.chargeAfter) return Result.retry()

        repo.markCharging(id)
        val key = "attempt_${o.attempts}_${o.idempotencyKey}"
        val fresh = repo.order(id) ?: return Result.success()
        val outcome = GatewayClient(applicationContext).charge(fresh)
        if (!repo.applyCharge(id, key, outcome)) return Result.success() // уже применено (идемпотентность)

        return when (outcome.result) {
            ChargeResult.UNKNOWN ->
                // Неопределённость не превращаем в долг и не шлём «плати»: только ретрай.
                if (fresh.attempts + 1 >= AppConfig.MAX_CHARGE_ATTEMPTS) Result.success()
                else Result.retry()

            ChargeResult.APPROVED -> {
                if (repo.debtMinor() == 0L) ReminderScheduler.disable(applicationContext)
                Result.success()
            }

            ChargeResult.PARTIAL, ChargeResult.DECLINED -> {
                ReminderScheduler.enable(applicationContext)
                DebtNotifier(applicationContext).show(repo.debtMinor())
                Result.success()
            }
        }
    }

    companion object {
        const val KEY_ORDER = "order_id"

        fun enqueue(ctx: Context, o: Order) {
            val delay = (o.chargeAfter - System.currentTimeMillis()).coerceAtLeast(0L)
            val req = OneTimeWorkRequestBuilder<ChargeWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(KEY_ORDER to o.id))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .addTag("charge:${o.id}")
                .build()
            WorkManager.getInstance(ctx).enqueueUniqueWork(
                "charge:${o.id}", ExistingWorkPolicy.KEEP, req
            )
        }
    }
}

package dev.aero.deferredpay.pay

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import dev.aero.deferredpay.data.LedgerRepository
import dev.aero.deferredpay.notify.DebtNotifier

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val repo = LedgerRepository(applicationContext)
        val debt = repo.debtMinor()
        if (debt <= 0L) {
            ReminderScheduler.disable(applicationContext) // погашено полностью -> молчим
            return Result.success()
        }
        DebtNotifier(applicationContext).show(debt)
        return Result.success()
    }
}

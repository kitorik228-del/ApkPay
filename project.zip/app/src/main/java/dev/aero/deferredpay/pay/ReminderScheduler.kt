package dev.aero.deferredpay.pay

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import dev.aero.deferredpay.config.AppConfig
import dev.aero.deferredpay.data.LedgerRepository
import dev.aero.deferredpay.notify.DebtNotifier
import java.util.concurrent.TimeUnit

object ReminderScheduler {
    const val WORK = "debt_reminders"

    fun enable(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<ReminderWorker>(
            AppConfig.REMINDER_PERIOD_MIN, TimeUnit.MINUTES
        ).addTag(WORK).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            WORK, ExistingPeriodicWorkPolicy.KEEP, req
        )
        LedgerRepository(ctx).setMeta("reminders_on", "1")
    }

    fun disable(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK)
        LedgerRepository(ctx).setMeta("reminders_on", "0")
        DebtNotifier(ctx).cancelAll()
    }
}

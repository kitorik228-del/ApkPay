package dev.aero.deferredpay.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import dev.aero.deferredpay.config.AppConfig
import dev.aero.deferredpay.money.Minor
import org.json.JSONObject
import java.util.UUID

/**
 * Единственный авторитет по подписке и долгу.
 * Ключевое правило: isEntitlementActive() НИКОГДА не читает orders, баланс или статус списания.
 * Именно поэтому подписка реально работает сразу при 0 грн на карте.
 */
class LedgerRepository(private val ctx: Context) {
    private val db = AppDatabase(ctx)

    private fun cv(vararg p: Pair<String, Any?>) = ContentValues().apply {
        p.forEach { (k, v) ->
            when (v) {
                null -> putNull(k)
                is String -> put(k, v)
                is Long -> put(k, v)
                is Int -> put(k, v)
                is Boolean -> put(k, if (v) 1 else 0)
                else -> error("unsupported ContentValues type: ${v.javaClass}")
            }
        }
    }

    private fun Cursor.toOrder() = Order(
        getString(getColumnIndexOrThrow("id")),
        getString(getColumnIndexOrThrow("sku")),
        getLong(getColumnIndexOrThrow("amount_minor")),
        getString(getColumnIndexOrThrow("currency")),
        getLong(getColumnIndexOrThrow("created_at")),
        getLong(getColumnIndexOrThrow("charge_after")),
        OrderStatus.valueOf(getString(getColumnIndexOrThrow("status"))),
        getLong(getColumnIndexOrThrow("captured_minor")),
        getString(getColumnIndexOrThrow("idempotency_key")),
        getInt(getColumnIndexOrThrow("attempts"))
    )

    private fun orderOn(w: SQLiteDatabase, id: String): Order? =
        w.query("orders", null, "id=?", arrayOf(id), null, null, null, "1")
            .use { if (it.moveToFirst()) it.toOrder() else null }

    fun order(id: String): Order? = orderOn(db.readableDatabase, id)

    fun pendingOrders(): List<Order> =
        db.readableDatabase.query(
            "orders", null, "status IN (?,?,?)",
            arrayOf(OrderStatus.GRANTED_PENDING_CHARGE.name, OrderStatus.CHARGING.name, OrderStatus.UNKNOWN.name),
            null, null, "created_at ASC"
        ).use { c -> buildList { while (c.moveToNext()) add(c.toOrder()) } }

    /** Долг = ТОЛЬКО подтверждённо-отказанные заказы. UNKNOWN (сеть/5xx/таймаут) долгом не считается. */
    private fun debtOn(w: SQLiteDatabase): Long = w.rawQuery(
        "SELECT COALESCE(SUM(amount_minor - captured_minor),0) FROM orders WHERE status=?",
        arrayOf(OrderStatus.UNPAID.name)
    ).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    fun debtMinor(): Long = debtOn(db.readableDatabase)

    fun isEntitlementActive(sku: String, now: Long = System.currentTimeMillis()): Boolean =
        db.readableDatabase.rawQuery(
            "SELECT 1 FROM entitlements WHERE sku=? AND revoked=0 AND valid_until>? LIMIT 1",
            arrayOf(sku, now.toString())
        ).use { it.moveToFirst() }

    fun meta(k: String): String? = db.readableDatabase.query(
        "meta", arrayOf("value"), "key=?", arrayOf(k), null, null, null, "1"
    ).use { if (it.moveToFirst()) it.getString(0) else null }

    private fun setMetaOn(w: SQLiteDatabase, k: String, v: String) {
        w.insertWithOnConflict("meta", null, cv("key" to k, "value" to v), SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun setMeta(k: String, v: String) {
        val w = db.writableDatabase
        w.tx { setMetaOn(w, k, v) }
    }

    /** ПОКУПКА: заказ + entitlement в ОДНОЙ транзакции, без всякого обращения к карте. */
    fun purchase(skuId: String, now: Long = System.currentTimeMillis()): Order {
        val sku = AppConfig.sku(skuId)
        val id = "ord_" + UUID.randomUUID().toString()
        val key = "chg_" + UUID.randomUUID().toString()
        val o = Order(
            id, sku.id, sku.priceMinor, AppConfig.CURRENCY, now,
            now + AppConfig.CHARGE_DELAY_MS, OrderStatus.GRANTED_PENDING_CHARGE,
            0L, key, 0
        )
        val w = db.writableDatabase
        w.tx {
            w.insert("orders", null, cv(
                "id" to o.id, "sku" to o.sku, "amount_minor" to o.amountMinor,
                "currency" to o.currency, "created_at" to o.createdAt,
                "charge_after" to o.chargeAfter, "status" to o.status.name,
                "captured_minor" to 0L, "idempotency_key" to o.idempotencyKey, "attempts" to 0
            ))
            w.insertWithOnConflict("entitlements", null, cv(
                "sku" to sku.id, "granted_at" to now,
                "valid_until" to now + sku.periodDays.toLong() * 86_400_000L,
                "revoked" to false, "source_order" to id
            ), SQLiteDatabase.CONFLICT_REPLACE)
        }
        return o
    }

    fun markCharging(id: String) {
        db.writableDatabase.update(
            "orders", cv("status" to OrderStatus.CHARGING.name), "id=?", arrayOf(id)
        )
    }

    /** Идемпотентно по (order_id, idempotency_key): повтор джоба не списывает второй раз. */
    fun applyCharge(
        orderId: String, key: String, outcome: ChargeOutcome,
        now: Long = System.currentTimeMillis()
    ): Boolean {
        val w = db.writableDatabase
        return w.tx {
            val dup = w.rawQuery(
                "SELECT 1 FROM charge_attempts WHERE order_id=? AND idempotency_key=? LIMIT 1",
                arrayOf(orderId, key)
            ).use { it.moveToFirst() }
            if (dup) return@tx false
            val o = orderOn(w, orderId) ?: return@tx false

            w.insert("charge_attempts", null, cv(
                "order_id" to orderId, "at" to now, "idempotency_key" to key,
                "result" to outcome.result.name, "captured_minor" to outcome.capturedMinor,
                "gateway_code" to outcome.gatewayCode
            ))

            val captured = (Minor(o.capturedMinor) + Minor(outcome.capturedMinor))
                .atMost(Minor(o.amountMinor)).raw
            val status = when (outcome.result) {
                ChargeResult.APPROVED -> OrderStatus.PAID
                ChargeResult.PARTIAL, ChargeResult.DECLINED -> OrderStatus.UNPAID
                ChargeResult.UNKNOWN -> OrderStatus.UNKNOWN
            }
            w.update("orders", cv(
                "captured_minor" to captured,
                "status" to status.name,
                "attempts" to if (outcome.result == ChargeResult.UNKNOWN) o.attempts + 1 else o.attempts
            ), "id=?", arrayOf(orderId))

            if (status == OrderStatus.UNPAID) setMetaOn(w, "reminders_on", "1")
            if (status == OrderStatus.PAID && debtOn(w) == 0L) setMetaOn(w, "reminders_on", "0")
            true
        }
    }

    /** Частичное погашение разрешено: напоминания живут, пока debt != 0. */
    fun applyRepayment(capturedMinor: Long, key: String): Long {
        require(capturedMinor >= 0)
        val w = db.writableDatabase
        return w.tx {
            val dup = w.rawQuery(
                "SELECT 1 FROM repayments WHERE idempotency_key=? LIMIT 1", arrayOf(key)
            ).use { it.moveToFirst() }
            if (dup) return@tx debtOn(w)

            w.insert("repayments", null, cv(
                "idempotency_key" to key, "at" to System.currentTimeMillis(),
                "captured_minor" to capturedMinor
            ))
            var left = Minor(capturedMinor)
            val unpaid = w.query(
                "orders", null, "status=?", arrayOf(OrderStatus.UNPAID.name),
                null, null, "created_at ASC"
            ).use { c -> buildList { while (c.moveToNext()) add(c.toOrder()) } }

            for (o in unpaid) {
                if (left.raw == 0L) break
                val pay = left.atMost(Minor(o.outstandingMinor))
                val cap = (Minor(o.capturedMinor) + pay).raw
                val st = if (cap >= o.amountMinor) OrderStatus.PAID else OrderStatus.UNPAID
                w.update("orders", cv("captured_minor" to cap, "status" to st.name),
                    "id=?", arrayOf(o.id))
                left = Minor(left.raw - pay.raw)
            }
            if (debtOn(w) == 0L) setMetaOn(w, "reminders_on", "0")
            debtOn(w)
        }
    }

    /** Подписанный /sync: сервер — окончательный авторитет, локальную БД можно было подменить на рутованном устройстве. */
    fun applySignedSnapshot(p: JSONObject) {
        val w = db.writableDatabase
        w.tx {
            w.delete("orders", null, null)
            w.delete("entitlements", null, null)
            val orders = p.getJSONArray("orders")
            for (i in 0 until orders.length()) {
                val o = orders.getJSONObject(i)
                w.insert("orders", null, cv(
                    "id" to o.getString("id"), "sku" to o.getString("sku"),
                    "amount_minor" to o.getLong("amount_minor"), "currency" to o.getString("currency"),
                    "created_at" to o.getLong("created_at"), "charge_after" to o.getLong("charge_after"),
                    "status" to o.getString("status"), "captured_minor" to o.getLong("captured_minor"),
                    "idempotency_key" to o.getString("idempotency_key"), "attempts" to o.getInt("attempts")
                ))
            }
            val ents = p.getJSONArray("entitlements")
            for (i in 0 until ents.length()) {
                val e = ents.getJSONObject(i)
                w.insert("entitlements", null, cv(
                    "sku" to e.getString("sku"), "granted_at" to e.getLong("granted_at"),
                    "valid_until" to e.getLong("valid_until"),
                    "revoked" to (e.getInt("revoked") != 0),
                    "source_order" to e.getString("source_order")
                ))
            }
        }
    }

    // --- симулятор карты (только при PAY_BASE_URL=UNSET) ---
    fun simCardMinor(): Long = meta("sim_card_minor")?.toLongOrNull() ?: 0L

    fun topUpSim(amount: Long) {
        require(amount > 0)
        setMeta("sim_card_minor", (Minor(simCardMinor()) + Minor(amount)).raw.toString())
    }

    fun debitSim(amount: Long) {
        require(amount <= simCardMinor()) { "sim balance underflow" }
        setMeta("sim_card_minor", (Minor(simCardMinor()) - Minor(amount)).raw.toString())
    }
}

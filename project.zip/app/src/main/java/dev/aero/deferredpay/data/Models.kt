package dev.aero.deferredpay.data

enum class OrderStatus { GRANTED_PENDING_CHARGE, CHARGING, UNPAID, UNKNOWN, PAID }
enum class ChargeResult { APPROVED, PARTIAL, DECLINED, UNKNOWN }

data class Order(
    val id: String, val sku: String, val amountMinor: Long, val currency: String,
    val createdAt: Long, val chargeAfter: Long, val status: OrderStatus,
    val capturedMinor: Long, val idempotencyKey: String, val attempts: Int
) {
    val outstandingMinor: Long get() = amountMinor - capturedMinor
}

data class ChargeOutcome(
    val result: ChargeResult, val capturedMinor: Long, val gatewayCode: String
)

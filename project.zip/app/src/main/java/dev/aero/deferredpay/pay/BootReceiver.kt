package dev.aero.deferredpay.pay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dev.aero.deferredpay.data.LedgerRepository

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (LedgerRepository(ctx).debtMinor() > 0L) ReminderScheduler.enable(ctx)
    }
}

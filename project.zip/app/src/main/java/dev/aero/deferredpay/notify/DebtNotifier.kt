package dev.aero.deferredpay.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import dev.aero.deferredpay.MainActivity
import dev.aero.deferredpay.money.MoneyFormat

class DebtNotifier(private val ctx: Context) {
    companion object {
        const val CHANNEL = "debt_reminders"
        const val ID = 4201
    }

    fun show(debtMinor: Long) {
        if (debtMinor <= 0L) return
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        val nm = ctx.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL, "Задолженность", NotificationManager.IMPORTANCE_HIGH)
        channel.description = "Напоминания до полного погашения"
        channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), null)
        channel.enableVibration(true)
        nm.createNotificationChannel(channel)

        val pi = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Задолженность ${MoneyFormat.debtUah(debtMinor)}")
            .setContentText("Погасите долг полностью, чтобы остановить напоминания. Подписка продолжает работать.")
            .setOngoing(true)
            .setAutoCancel(false)
            .setOnlyAlertOnce(false)
            .setContentIntent(pi)
            .build()
        nm.notify(ID, n)
    }

    fun cancelAll() {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID)
    }
}

package dev.aero.deferredpay.money

/** Только целые минорные единицы (копейки). Float/Double для денег не используются. */
@JvmInline
value class Minor(val raw: Long) {
    init { require(raw >= 0) { "minor units must be non-negative: $raw" } }
    operator fun plus(other: Minor) = Minor(Math.addExact(raw, other.raw))
    operator fun minus(other: Minor) = Minor(raw - other.raw)
    fun atMost(other: Minor) = if (raw <= other.raw) this else other
}

object MoneyFormat {
    private fun group(major: Long): String =
        major.toString().reversed().chunked(3).joinToString(" ").reversed()

    private fun frac2(frac: Long): String = "%02d".format(frac)

    /** 2_400_000 -> "-24 000 грн". Долг хранится ПОЛОЖИТЕЛЬНЫМ, минус только на экране. */
    fun debtUah(debtMinor: Long): String {
        require(debtMinor >= 0)
        val frac = debtMinor % 100
        return if (frac == 0L) "-${group(debtMinor / 100)} грн"
        else "-${group(debtMinor / 100)},${frac2(frac)} грн"
    }

    fun uah(minor: Long): String {
        val sign = if (minor < 0) "-" else ""
        val a = kotlin.math.abs(minor)
        val frac = a % 100
        return if (frac == 0L) "$sign${group(a / 100)} грн"
        else "$sign${group(a / 100)},${frac2(frac)} грн"
    }
}

package dev.aero.deferredpay.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AppDatabase(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "deferredpay.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE orders(
            id TEXT PRIMARY KEY, sku TEXT NOT NULL, amount_minor INTEGER NOT NULL,
            currency TEXT NOT NULL, created_at INTEGER NOT NULL, charge_after INTEGER NOT NULL,
            status TEXT NOT NULL, captured_minor INTEGER NOT NULL DEFAULT 0,
            idempotency_key TEXT NOT NULL UNIQUE, attempts INTEGER NOT NULL DEFAULT 0)""")
        db.execSQL("""CREATE TABLE entitlements(
            sku TEXT PRIMARY KEY, granted_at INTEGER NOT NULL, valid_until INTEGER NOT NULL,
            revoked INTEGER NOT NULL DEFAULT 0, source_order TEXT NOT NULL)""")
        db.execSQL("""CREATE TABLE charge_attempts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT NOT NULL, at INTEGER NOT NULL,
            idempotency_key TEXT NOT NULL, result TEXT NOT NULL, captured_minor INTEGER NOT NULL,
            gateway_code TEXT NOT NULL, UNIQUE(order_id, idempotency_key))""")
        db.execSQL("""CREATE TABLE repayments(
            idempotency_key TEXT PRIMARY KEY, at INTEGER NOT NULL, captured_minor INTEGER NOT NULL)""")
        db.execSQL("CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execSQL("INSERT INTO meta(key,value) VALUES('sim_card_minor','0')")
        db.execSQL("INSERT INTO meta(key,value) VALUES('reminders_on','0')")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Схема v1: миграций нет. Не дропаем молча чужие данные.
        error("unsupported schema upgrade $oldVersion -> $newVersion")
    }
}

inline fun <T> SQLiteDatabase.tx(block: () -> T): T {
    beginTransaction()
    try {
        val r = block()
        setTransactionSuccessful()
        return r
    } finally {
        endTransaction()
    }
}

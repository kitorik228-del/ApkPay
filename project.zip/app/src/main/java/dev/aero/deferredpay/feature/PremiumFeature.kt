package dev.aero.deferredpay.feature

import android.content.Context
import android.util.Base64
import dev.aero.deferredpay.data.LedgerRepository
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object PremiumFeature {
    class EntitlementRequired : IllegalStateException("Премиум-подписка не активна")

    fun run(ctx: Context, input: String): String {
        val repo = LedgerRepository(ctx)
        if (!repo.isEntitlementActive("premium_year") && !repo.isEntitlementActive("premium_month"))
            throw EntitlementRequired()
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec("aero-deferredpay-premium-v1".toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return Base64.encodeToString(mac.doFinal(input.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }
}

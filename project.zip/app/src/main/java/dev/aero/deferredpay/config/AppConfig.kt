package dev.aero.deferredpay.config

import dev.aero.deferredpay.BuildConfig

/**
 * ЕДИНЫЙ конфиг проекта. Provenance каждого значения:
 *  - CHARGE_DELAY_MS = 120_000  : из условия задачи («через 2 минуты»), не из билда/таргета.
 *  - REMINDER_PERIOD_MIN = 15   : системный минимум WorkManager (не «постоянно», см. README).
 *  - CURRENCY = "UAH"           : из условия (грн).
 *  - цена 2_400_000 коп.        : пример из условия (24 000 грн), НЕ подтверждённый прайс.
 *  - PAY_BASE_URL               : НЕ задан пользователем. "UNSET" = явное «не задано»,
 *                                это НЕ ноль и НЕ localhost. При UNSET работает LocalSim.
 *  - PAY_SYNC_SECRET            : "UNSET" = подпись /sync отключена (fail-closed), не пустой ключ.
 */
object AppConfig {
    const val CHARGE_DELAY_MS = 120_000L
    const val REMINDER_PERIOD_MIN = 15L
    const val HTTP_TIMEOUT_MS = 15_000
    const val MAX_CHARGE_ATTEMPTS = 6
    const val CURRENCY = "UAH"

    val baseUrl: String get() = BuildConfig.PAY_BASE_URL
    val syncSecret: String? get() = BuildConfig.PAY_SYNC_SECRET.takeIf { it != "UNSET" && it.isNotBlank() }
    val httpConfigured: Boolean get() = baseUrl.startsWith("http://") || baseUrl.startsWith("https://")
    val syncVerifiable: Boolean get() = syncSecret != null

    data class Sku(val id: String, val title: String, val priceMinor: Long, val periodDays: Int)

    val catalog = listOf(
        Sku("premium_year", "Премиум · 12 мес.", 2_400_000L, 365),
        Sku("premium_month", "Премиум · 1 мес.", 19_900L, 30)
    )

    fun sku(id: String): Sku = catalog.first { it.id == id }
}

package dev.aero.deferredpay

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import dev.aero.deferredpay.config.AppConfig
import dev.aero.deferredpay.data.ChargeResult
import dev.aero.deferredpay.data.LedgerRepository
import dev.aero.deferredpay.feature.PremiumFeature
import dev.aero.deferredpay.money.MoneyFormat
import dev.aero.deferredpay.notify.DebtNotifier
import dev.aero.deferredpay.pay.ChargeWorker
import dev.aero.deferredpay.pay.GatewayClient
import dev.aero.deferredpay.pay.ReminderScheduler
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var repo: LedgerRepository
    private lateinit var gateway: GatewayClient
    private lateinit var statusView: TextView
    private lateinit var debtView: TextView
    private lateinit var cardView: TextView
    private lateinit var timerView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = LedgerRepository(this)
        gateway = GatewayClient(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(32, 64, 32, 32)
        root.setBackgroundColor(Color.rgb(0x12, 0x14, 0x18))

        fun addText(size: Float, bold: Boolean): TextView {
            val t = TextView(this)
            t.textSize = size
            if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            t.setTextColor(Color.rgb(0xE8, 0xE8, 0xE8))
            root.addView(t)
            return t
        }

        fun addButton(label: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.isAllCaps = false
            b.setOnClickListener {
                onClick()
                refresh()
            }
            root.addView(b)
        }

        addText(20f, true).text = "DeferredPay"
        addText(13f, false).text =
            "Подписка сразу · попытка списания через ${AppConfig.CHARGE_DELAY_MS / 1000} с"
        statusView = addText(16f, false)
        debtView = addText(30f, true)
        cardView = addText(15f, false)
        timerView = addText(14f, false)

        addButton("Купить Премиум · 12 мес. · 24 000 грн") {
            val o = repo.purchase("premium_year")
            ChargeWorker.enqueue(this, o)
            toast("Подписка активирована немедленно. Списание через 2 мин.")
        }
        addButton("Проверить премиум-функцию") {
            try {
                toast("HMAC = " + PremiumFeature.run(this, "probe"))
            } catch (e: PremiumFeature.EntitlementRequired) {
                toast("Доступ закрыт")
            }
        }
        addButton("Пополнить карту +25 000 грн (sim)") {
            gateway.topUp(2_500_000L)
            toast("Баланс карты пополнен")
        }
        addButton("Погасить долг") {
            repay()
        }
        addButton("Синхронизировать с сервером") {
            toast(gateway.syncFromServer().reason)
        }

        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    private fun repay() {
        val d = repo.debtMinor()
        if (d == 0L) {
            toast("Долга нет")
            return
        }
        val key = "rep_" + UUID.randomUUID().toString()
        val out = gateway.repay(d, key)
        if (out.result == ChargeResult.UNKNOWN) {
            toast("Шлюз недоступен, повторите позже")
            return
        }
        val left = repo.applyRepayment(out.capturedMinor, key)
        if (left == 0L) ReminderScheduler.disable(this)
        toast(if (left == 0L) "Долг погашен полностью" else "Остаток ${MoneyFormat.debtUah(left)}")
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
        val d = repo.debtMinor()
        if (d > 0L) DebtNotifier(this).show(d) // напоминание при каждом открытии
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun refresh() {
        val active = repo.isEntitlementActive("premium_year") || repo.isEntitlementActive("premium_month")
        statusView.text = "Подписка: " + if (active)
            "АКТИВНА (выдана сразу, не зависит от списания)" else "не активна"

        val d = repo.debtMinor()
        debtView.text = when {
            d > 0L -> MoneyFormat.debtUah(d)
            repo.pendingOrders().isNotEmpty() -> "Списание ещё не подтверждено…"
            else -> "0 грн"
        }
        cardView.text = "Карта: " + MoneyFormat.uah(gateway.cardMinor())

        val next = repo.pendingOrders().minByOrNull { it.chargeAfter }?.chargeAfter
        timerView.text = if (next != null)
            "До попытки списания: ${((next - System.currentTimeMillis()).coerceAtLeast(0L)) / 1000} с"
        else "Очередных попыток списания нет"

        if (d == 0L && repo.meta("reminders_on") == "1") ReminderScheduler.disable(this)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}

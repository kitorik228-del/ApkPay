# Запуск и удаление

Сервер (Python 3, только stdlib):
  cd server
  python3 server.py --host 0.0.0.0 --port 8787 --db ./deferredpay.db \
      --gateway sim --hmac-secret "$PAY_SYNC_SECRET"

Клиент:
  cp local.properties.example local.properties
  PAY_BASE_URL=http://10.0.2.2:8787   (эмулятор) / http://<ip>:8787 (устройство)
  PAY_SYNC_SECRET=<тот же, что --hmac-secret>
  gradle :app:assembleDebug

Что пишется:
  APK: /data/data/dev.aero.deferredpay/databases/deferredpay.db + задачи WorkManager.
  Сервер: ./deferredpay.db (orders, entitlements, charge_attempts, repayments, meta).
  Уведомления: канал "debt_reminders", id 4201, ongoing до обнуления долга.

Полное удаление:
  adb uninstall dev.aero.deferredpay
  adb shell pm clear dev.aero.deferredpay          (если нужно только обнулить реестр)
  rm -f server/deferredpay.db && pkill -f server.py
  Напоминания снимаются сами при debt == 0: ReminderWorker -> cancelUniqueWork + cancel(4201).

Реальный шлюз: заменить build_gateway("real") своим адаптером, хранить merchant-ключи
только на сервере, в APK оставить лишь непрозрачный token_ref; перевести BASE_URL на HTTPS
и убрать usesCleartextTraffic.

"""Серверный авторитет. Та же машина состояний, что в LedgerRepository.kt. Деньги — целые копейки."""
import sqlite3
import time
import uuid

CHARGE_DELAY_MS = 120_000
DAY_MS = 86_400_000

SCHEMA = """
CREATE TABLE IF NOT EXISTS orders(
    id TEXT PRIMARY KEY, sku TEXT NOT NULL, amount_minor INTEGER NOT NULL,
    currency TEXT NOT NULL, created_at INTEGER NOT NULL, charge_after INTEGER NOT NULL,
    status TEXT NOT NULL, captured_minor INTEGER NOT NULL DEFAULT 0,
    idempotency_key TEXT NOT NULL UNIQUE, attempts INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS entitlements(
    sku TEXT PRIMARY KEY, granted_at INTEGER NOT NULL, valid_until INTEGER NOT NULL,
    revoked INTEGER NOT NULL DEFAULT 0, source_order TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS charge_attempts(
    id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT NOT NULL, at INTEGER NOT NULL,
    idempotency_key TEXT NOT NULL, result TEXT NOT NULL, captured_minor INTEGER NOT NULL,
    gateway_code TEXT NOT NULL, UNIQUE(order_id, idempotency_key));
CREATE TABLE IF NOT EXISTS repayments(
    idempotency_key TEXT PRIMARY KEY, at INTEGER NOT NULL, captured_minor INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


def format_debt_uah(debt_minor):
    assert debt_minor >= 0
    major, frac = divmod(debt_minor, 100)
    grouped = f"{major:,}".replace(",", " ")
    return f"-{grouped} грн" if frac == 0 else f"-{grouped},{frac:02d} грн"


class Ledger:
    def __init__(self, conn, gateway):
        self.c = conn
        self.gw = gateway
        self.c.executescript(SCHEMA)
        self.c.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('sim_card_minor','0')")
        self.c.commit()

    # --- entitlement НЕ читает orders/баланс/статус оплаты ---
    def entitlement_active(self, sku, now=None):
        now = now or int(time.time() * 1000)
        return self.c.execute(
            "SELECT 1 FROM entitlements WHERE sku=? AND revoked=0 AND valid_until>? LIMIT 1",
            (sku, now)).fetchone() is not None

    def debt(self):
        return int(self.c.execute(
            "SELECT COALESCE(SUM(amount_minor - captured_minor),0) FROM orders WHERE status='UNPAID'"
        ).fetchone()[0])

    def card_minor(self):
        return int(self.c.execute(
            "SELECT value FROM meta WHERE key='sim_card_minor'").fetchone()[0])

    def purchase(self, sku, amount_minor, currency="UAH", period_days=365, now=None):
        now = now or int(time.time() * 1000)
        oid = "ord_" + uuid.uuid4().hex
        key = "chg_" + uuid.uuid4().hex
        with self.c:
            self.c.execute(
                "INSERT INTO orders(id,sku,amount_minor,currency,created_at,charge_after,"
                "status,captured_minor,idempotency_key,attempts) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (oid, sku, amount_minor, currency, now, now + CHARGE_DELAY_MS,
                 "GRANTED_PENDING_CHARGE", 0, key, 0))
            self.c.execute(
                "INSERT OR REPLACE INTO entitlements(sku,granted_at,valid_until,revoked,source_order)"
                " VALUES(?,?,?,0,?)", (sku, now, now + period_days * DAY_MS, oid))
        return oid

    def charge(self, order_id, idempotency_key=None, now=None):
        now = now or int(time.time() * 1000)
        r = self.c.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if r is None:
            raise KeyError(order_id)

        key = idempotency_key or ("chg_" + uuid.uuid4().hex)
        # Идемпотентность проверяем ПЕРВОЙ: повтор с тем же ключом отдаёт сохранённый результат.
        dup = self.c.execute(
            "SELECT result,captured_minor,gateway_code FROM charge_attempts "
            "WHERE order_id=? AND idempotency_key=?", (order_id, key)).fetchone()
        if dup:
            return dict(dict(dup), debt_minor=self.debt())

        if r["status"] == "PAID":
            return dict(result="APPROVED", captured_minor=0,
                        gateway_code="already_paid", debt_minor=self.debt())
        if now < r["charge_after"]:
            return dict(result="UNKNOWN", captured_minor=0,
                        gateway_code="too_early", debt_minor=self.debt())

        out = self.gw.charge(r["amount_minor"] - r["captured_minor"], key)
        cap = min(r["amount_minor"], r["captured_minor"] + out.captured_minor)
        status = {"APPROVED": "PAID", "PARTIAL": "UNPAID",
                  "DECLINED": "UNPAID", "UNKNOWN": "UNKNOWN"}[out.result]
        with self.c:
            self.c.execute(
                "INSERT INTO charge_attempts(order_id,at,idempotency_key,result,"
                "captured_minor,gateway_code) VALUES(?,?,?,?,?,?)",
                (order_id, now, key, out.result, out.captured_minor, out.gateway_code))
            self.c.execute("UPDATE orders SET captured_minor=?, status=?, attempts=attempts+? WHERE id=?",
                           (cap, status, 1 if out.result == "UNKNOWN" else 0, order_id))
        return dict(result=out.result, captured_minor=out.captured_minor,
                    gateway_code=out.gateway_code, debt_minor=self.debt())

    def repay(self, requested_minor, idempotency_key):
        if self.c.execute("SELECT 1 FROM repayments WHERE idempotency_key=?",
                          (idempotency_key,)).fetchone():
            return dict(result="APPROVED", captured_minor=0,
                        gateway_code="duplicate", debt_minor=self.debt())
        out = self.gw.repay(requested_minor, idempotency_key)
        left = out.captured_minor
        with self.c:
            self.c.execute("INSERT INTO repayments VALUES(?,?,?)",
                           (idempotency_key, int(time.time() * 1000), out.captured_minor))
            rows = self.c.execute(
                "SELECT * FROM orders WHERE status='UNPAID' ORDER BY created_at").fetchall()
            for o in rows:
                if left == 0:
                    break
                pay = min(left, o["amount_minor"] - o["captured_minor"])
                cap = o["captured_minor"] + pay
                st = "PAID" if cap >= o["amount_minor"] else "UNPAID"
                self.c.execute("UPDATE orders SET captured_minor=?, status=? WHERE id=?",
                               (cap, st, o["id"]))
                left -= pay
        return dict(result=out.result, captured_minor=out.captured_minor,
                    gateway_code=out.gateway_code, debt_minor=self.debt())

    def topup(self, amount_minor):
        assert amount_minor > 0
        with self.c:
            self.c.execute("UPDATE meta SET value=? WHERE key='sim_card_minor'",
                           (str(self.card_minor() + amount_minor),))
        return self.card_minor()

    def snapshot(self):
        return dict(
            debt_minor=self.debt(),
            orders=[dict(r) for r in self.c.execute("SELECT * FROM orders ORDER BY created_at")],
            entitlements=[dict(r) for r in self.c.execute("SELECT * FROM entitlements")],
        )

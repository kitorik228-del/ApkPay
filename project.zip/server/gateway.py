"""Граница шлюза. SimGateway — полная реализация. Поля реального провайдера НЕ выдумываются."""
from dataclasses import dataclass


@dataclass
class ChargeResult:
    result: str            # APPROVED | PARTIAL | DECLINED | UNKNOWN
    captured_minor: int
    gateway_code: str


class SimGateway:
    """Карта 0 грн по умолчанию. Воспроизводит insufficient_funds. НЕ реальный банк."""

    def __init__(self, conn):
        self.c = conn

    def _balance(self):
        return int(self.c.execute(
            "SELECT value FROM meta WHERE key='sim_card_minor'").fetchone()[0])

    def _debit(self, n):
        self.c.execute("UPDATE meta SET value=? WHERE key='sim_card_minor'",
                       (str(self._balance() - n),))

    def charge(self, amount_minor, idempotency_key):
        if self._balance() < amount_minor:
            return ChargeResult("DECLINED", 0, "sim:insufficient_funds")
        self._debit(amount_minor)
        return ChargeResult("APPROVED", amount_minor, "sim:approved")

    def repay(self, requested_minor, idempotency_key):
        bal = self._balance()
        if bal <= 0:
            return ChargeResult("DECLINED", 0, "sim:insufficient_funds")
        cap = min(bal, requested_minor)
        self._debit(cap)
        return ChargeResult("APPROVED" if cap == requested_minor else "PARTIAL",
                            cap, "sim:approved_partial")


def build_gateway(mode, conn):
    if mode == "sim":
        return SimGateway(conn)
    if mode == "real":
        # Fail-fast вместо тихого стаба: перечислены ровно те входные данные, которых нет.
        raise RuntimeError(
            "реальный шлюз не сконфигурирован: отсутствуют провайдер, merchant endpoint, "
            "token_ref/карточный токен, таблица кодов ответа и правила partial capture. "
            "Реализуй класс с charge()/repay() по документации своего провайдера и "
            "передай его в build_gateway(). Коды и поля провайдера не подставляются наугад."
        )
    raise ValueError("unknown gateway mode: " + str(mode))

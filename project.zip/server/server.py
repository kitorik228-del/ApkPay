#!/usr/bin/env python3
"""DeferredPay reference server: stdlib only. Запуск см. runbook.md."""
import argparse
import hashlib
import hmac
import json
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from gateway import build_gateway
from ledger import Ledger

STATE = {}


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        body = canonical(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length", "0"))
        if n <= 0:
            return {}
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def do_GET(self):
        L = STATE["ledger"]
        if self.path == "/balance":
            return self._send(200, {"card_minor": L.card_minor()})
        if self.path == "/sync":
            secret = STATE["secret"]
            if not secret:
                return self._send(409, {"error": "hmac secret unset: /sync disabled (fail-closed)"})
            body = canonical(L.snapshot())
            sig = hmac.new(secret.encode("utf-8"), body.encode("utf-8"), hashlib.sha256).hexdigest()
            # canonical передаётся строкой, чтобы байты для HMAC были детерминированы
            return self._send(200, {"canonical": body, "sig": sig})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        L = STATE["ledger"]
        try:
            b = self._body()
            if self.path == "/purchase":
                oid = L.purchase(b["sku"], int(b["amount_minor"]), b.get("currency", "UAH"),
                                 int(b.get("period_days", 365)))
                return self._send(201, {"order_id": oid, "status": "GRANTED_PENDING_CHARGE",
                                        "debt_minor": L.debt()})
            if self.path == "/charge":
                return self._send(200, L.charge(b["order_id"], b.get("idempotency_key")))
            if self.path == "/repay":
                return self._send(200, L.repay(int(b["amount_minor"]), b["idempotency_key"]))
            if self.path == "/topup":
                return self._send(200, {"card_minor": L.topup(int(b["amount_minor"]))})
            return self._send(404, {"error": "not found"})
        except KeyError as e:
            return self._send(400, {"error": "missing field: " + str(e)})
        except Exception as e:
            return self._send(500, {"error": str(e)})

    def log_message(self, fmt, *args):
        print("[deferredpay] " + (fmt % args))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--db", default="./deferredpay.db")
    ap.add_argument("--gateway", choices=["sim", "real"], default="sim")
    ap.add_argument("--hmac-secret", default="")
    args = ap.parse_args()

    conn = sqlite3.connect(args.db, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    gw = build_gateway(args.gateway, conn)
    STATE["ledger"] = Ledger(conn, gw)
    STATE["secret"] = args.hmac_secret
    print(f"[deferredpay] {args.host}:{args.port} db={args.db} gateway={args.gateway} "
          f"sync={'on' if args.hmac_secret else 'OFF (fail-closed)'}")
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()


if __name__ == "__main__":
    main()

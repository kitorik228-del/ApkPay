# Протокол DeferredPay (этот проект, не спецификация какого-либо провайдера)

Все суммы — INTEGER в минорных единицах (копейках). Валюта "UAH". Время — epoch milliseconds.

POST /purchase {sku, amount_minor, currency?, period_days?}
  -> 201 {order_id, status:"GRANTED_PENDING_CHARGE", debt_minor}
     Сервер СРАЗУ пишет entitlements, не обращаясь к карте.

POST /charge {order_id, idempotency_key}
  -> 200 {result, captured_minor, gateway_code, debt_minor}
     result: APPROVED | PARTIAL | DECLINED | UNKNOWN
     Повтор с тем же idempotency_key возвращает сохранённый результат без повторного списания.
     too_early (now < charge_after) -> UNKNOWN, долг не создаётся.

POST /repay {amount_minor, idempotency_key}
  -> 200 {result, captured_minor, gateway_code, debt_minor}
     PARTIAL -> captured_minor > 0, долг уменьшается, но не обнуляется.

POST /topup {amount_minor}       <- только режим sim; моделирует пополнение карты
GET  /balance -> {card_minor}    <- только режим sim
GET  /sync   -> {canonical: "<JSON-строка>", sig: "<hex hmac-sha256(secret, canonical)>"}
     Без --hmac-secret: 409 и никакой подписи пустым ключом.
     Клиент сверяет подпись в constant-time и только потом применяет снапшот.

Статусы заказа: GRANTED_PENDING_CHARGE -> CHARGING -> PAID | UNPAID | UNKNOWN
Долг = SUM(amount_minor - captured_minor) WHERE status='UNPAID'.
UNKNOWN (сеть/5xx/таймаут) НЕ является долгом: это ретрай, а не «плати».

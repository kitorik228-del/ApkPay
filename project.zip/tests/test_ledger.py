import os
import sqlite3
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "server"))
from gateway import SimGateway          # noqa: E402
from ledger import Ledger, format_debt_uah, CHARGE_DELAY_MS  # noqa: E402

NOW = 1_700_000_000_000
PRICE = 2_400_000  # 24 000 грн


class DeferredPayFlow(unittest.TestCase):
    def setUp(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.L = Ledger(self.conn, SimGateway(self.conn))

    def test_zero_balance_expensive_sub_activates_and_becomes_debt(self):
        oid = self.L.purchase("premium_year", PRICE, now=NOW)
        # 1) карта 0 грн
        self.assertEqual(self.L.card_minor(), 0)
        # 2) подписка УЖЕ работает ДО всякого списания
        self.assertTrue(self.L.entitlement_active("premium_year", now=NOW))
        self.assertEqual(self.L.debt(), 0)  # долга ещё нет: «через некоторое время»
        # 3) раньше 2 минут отказом не считается
        early = self.L.charge(oid, "k_early", now=NOW + CHARGE_DELAY_MS - 1)
        self.assertEqual(early["result"], "UNKNOWN")
        self.assertEqual(self.L.debt(), 0)
        # 4) ровно через 2 минуты -> insufficient_funds -> -24 000 грн
        r = self.L.charge(oid, "k_main", now=NOW + CHARGE_DELAY_MS)
        self.assertEqual(r["result"], "DECLINED")
        self.assertEqual(r["gateway_code"], "sim:insufficient_funds")
        self.assertEqual(self.L.debt(), PRICE)
        self.assertEqual(format_debt_uah(self.L.debt()), "-24 000 грн")
        # 5) подписка ПРОДОЛЖАЕТ работать при долге
        self.assertTrue(self.L.entitlement_active("premium_year", now=NOW + CHARGE_DELAY_MS))

    def test_idempotent_retry_never_double_charges(self):
        self.L.topup(PRICE)
        oid = self.L.purchase("premium_year", PRICE, now=NOW)
        first = self.L.charge(oid, "k1", now=NOW + CHARGE_DELAY_MS)
        self.assertEqual(first["result"], "APPROVED")
        self.assertEqual(self.L.debt(), 0)
        self.assertEqual(self.L.card_minor(), 0)
        # повтор с тем же ключом: сохранённый результат, второго списания нет
        again = self.L.charge(oid, "k1", now=NOW + CHARGE_DELAY_MS + 1)
        self.assertEqual(again["result"], "APPROVED")
        self.assertEqual(again["gateway_code"], "sim:approved")
        self.assertEqual(self.L.card_minor(), 0)
        # другой ключ по уже оплаченному заказу: тоже не списывает
        other = self.L.charge(oid, "k2", now=NOW + CHARGE_DELAY_MS + 2)
        self.assertEqual(other["gateway_code"], "already_paid")
        self.assertEqual(self.L.card_minor(), 0)
        self.assertTrue(self.L.entitlement_active("premium_year", now=NOW + CHARGE_DELAY_MS))

    def test_partial_repay_keeps_debt_then_full_repay_clears(self):
        oid = self.L.purchase("premium_year", PRICE, now=NOW)
        self.L.charge(oid, "k1", now=NOW + CHARGE_DELAY_MS)
        self.L.topup(1_000_000)  # 10 000 грн
        r1 = self.L.repay(self.L.debt(), "rep1")
        self.assertEqual(r1["result"], "PARTIAL")
        self.assertEqual(self.L.debt(), 1_400_000)
        self.assertEqual(format_debt_uah(self.L.debt()), "-14 000 грн")
        self.L.topup(1_400_000)
        r2 = self.L.repay(self.L.debt(), "rep2")
        self.assertEqual(r2["debt_minor"], 0)
        self.assertEqual(self.L.debt(), 0)  # условие остановки напоминаний
        self.assertEqual(self.L.repay(1, "rep2")["gateway_code"], "duplicate")

    def test_money_format(self):
        self.assertEqual(format_debt_uah(0), "-0 грн")
        self.assertEqual(format_debt_uah(2_400_000), "-24 000 грн")
        self.assertEqual(format_debt_uah(1_234_567), "-12 345,67 грн")


if __name__ == "__main__":
    unittest.main(verbosity=2)
